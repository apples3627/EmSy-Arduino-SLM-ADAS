#pragma once
namespace MainLinks {
struct Link {Proto::Frame request,response;uint32_t deadline,gap;volatile uint8_t phase,index;uint8_t retries;volatile bool done,ok;};
Link bus[2];
inline void twGo(uint8_t flags){TWCR=_BV(TWINT)|_BV(TWEN)|_BV(TWIE)|flags;}
inline void begin(uint8_t w,const Proto::Frame& f,uint32_t now){Link& b=bus[w];b.request=f;b.phase=1;b.index=0;b.retries=0;b.done=false;b.ok=false;b.deadline=now+100;if(!w)twGo(_BV(TWSTA));else{PORTB&=~_BV(PORTB2);__builtin_avr_delay_cycles(160);SPDR=f.bytes[0];}}
inline void finish(uint8_t w,bool ok){Link& b=bus[w];b.ok=ok&&Proto::valid(b.response);if(w){PORTB|=_BV(PORTB2);b.phase=0;b.done=true;}else{TWCR=_BV(TWINT)|_BV(TWEN)|_BV(TWSTO);b.deadline=MainIO::ticks+100;b.phase=10;}}
inline void service(uint8_t w,uint32_t now,bool interrupt=false){Link& b=bus[w];if(!b.phase)return;if(!w&&(b.phase==10||b.phase==11)){bool canceled=b.phase==11;if(TWCR&_BV(TWSTO)){if(int32_t(now-b.deadline)<0)return;TWCR=0;TWCR=_BV(TWEN);b.ok=false;}b.phase=0;b.done=!canceled;return;}if(int32_t(now-b.deadline)>=0){finish(w,false);return;}if(!w&&!interrupt&&(b.phase==1||b.phase==2||b.phase==6||b.phase==7||b.phase==8))return;
 if(w){if(b.phase==2){if(int32_t(now-b.gap)<0)return;PORTB&=~_BV(PORTB2);__builtin_avr_delay_cycles(160);b.index=0;b.phase=3;SPDR=0xff;return;}if(!(SPSR&_BV(SPIF)))return;uint8_t v=SPDR;if(b.phase==3)b.response.bytes[b.index]=v;if(++b.index==32){PORTB|=_BV(PORTB2);if(b.phase==1){b.phase=2;b.gap=now+2;}else finish(w,true);return;}__builtin_avr_delay_cycles(256);SPDR=b.phase==1?b.request.bytes[b.index]:0xff;return;}
 if(b.phase==4){if(TWCR&_BV(TWSTO))return;b.phase=5;b.gap=now+2;return;}if(b.phase==5){if(int32_t(now-b.gap)<0)return;b.phase=6;twGo(_BV(TWSTA));return;}if(b.phase==9){if(TWCR&_BV(TWSTO))return;finish(0,true);return;}if(!(TWCR&_BV(TWINT)))return;uint8_t s=TWSR&0xf8;switch(b.phase){case 1:if(s!=8&&s!=16){finish(0,false);break;}TWDR=0x24;b.phase=2;twGo(0);break;case 2:if(s!=0x18&&s!=0x28){finish(0,false);break;}if(b.index==32){TWCR=_BV(TWINT)|_BV(TWEN)|_BV(TWSTO);b.phase=4;}else{TWDR=b.request.bytes[b.index++];twGo(0);}break;case 6:if(s!=8&&s!=16){finish(0,false);break;}TWDR=0x25;b.phase=7;twGo(0);break;case 7:if(s!=0x40){finish(0,false);break;}b.index=0;b.phase=8;twGo(_BV(TWEA));break;case 8:if(s!=0x50&&s!=0x58){finish(0,false);break;}b.response.bytes[b.index++]=TWDR;if(b.index==32){TWCR=_BV(TWINT)|_BV(TWEN)|_BV(TWSTO);b.phase=9;}else twGo(b.index==31?0:_BV(TWEA));break;default:finish(0,false);}}
}

ISR(TWI_vect){MainLinks::service(0,MainIO::ticks,true);}
