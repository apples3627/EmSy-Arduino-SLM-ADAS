# main 보드 업로드 시작

ZIP을 풀어 main 폴더 전체를 유지하고 main.ino를 Arduino IDE에서 여세요. src/를 함께 둡니다.

[보드별 업로드·배선 지침](GUIDE.md) · [전체 핀 연결표](PIN_MAP.md) · [팀 통합 체크리스트](INTEGRATION_CHECKLIST.md)

Arduino Uno R3/ATmega328P/16MHz를 선택하고 자기 보드 포트를 확인합니다. 외부 배선을 분리한 상태에서 업로드하세요. 네 보드 모두의 역할별 코드가 있어야 협력 동작합니다. 이 ZIP은 main 담당자용입니다.
